<?php 

/**
* Load the base class
*/
class LP_Paid_Transaction extends LP_Transaction {
	
	function __construct()	{
		
	}

	public function createTransaction() 
	{
		
	}

	public function getTransaction() 
	{
		
	}

}